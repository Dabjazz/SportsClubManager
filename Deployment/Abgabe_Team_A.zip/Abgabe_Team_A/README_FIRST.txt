 _______  _______  _______  ______     _______  _______ 
(  ____ )(  ____ \(  ___  )(  __  \   (       )(  ____ \
| (    )|| (    \/| (   ) || (  \  )  | () () || (    \/
| (____)|| (__    | (___) || |   ) |  | || || || (__    
|     __)|  __)   |  ___  || |   | |  | |(_)| ||  __)   
| (\ (   | (      | (   ) || |   ) |  | |   | || (      
| ) \ \__| (____/\| )   ( || (__/  )  | )   ( || (____/\
|/   \__/(_______/|/     \|(______/   |/     \|(_______/


Datenbank:
==========
Hier einfach eine MySQL Datenbank erstellen, die "SportClubManagement" heißt und darin 
einfach das "script_with_data.sql" einspielen.

Ausführen:
==========

 RMI und CORBA:
 --------------
   Um diese Applikation zu starten zuerst in den Folder Server gehen und darin das Server.jar
   ausführen. Nach 5 Sekunden sollte der Server funktionsbereit sein. Wenn man dieses JAR
   in der Kommandozeile ausführt einfach "java -jar path_to/Server.jar" und "path_to" durch
   einen absoluten oder relativen Pfad ersetzen.

   Danach die selbe Prozedur für das Client.jar im Folder Client. Einfach doppelklicken oder 
   "java -jar path_to/Client.jar" und "path_to" durch einen absoluten oder relativen Pfad 
   ersetzen.

 JMS:
 ----
   Zuerst müssen im Glassfish folgende Factories erstellt werden: 
    - topic/memberAddedToClubTeamFactory
    - topic/memberAddedToDepartmentFactory

   Danach folgende Topics werden:
    - topic/memberAddedToClubTeamTopic
    - topic/memberAddedToDepartmentTopic

   Danach können die Jars gestartet werden:
   ........................................

     Client und Server beim Glassfish registrieren und Client mit dem Argument "Team" 
     oder "Member" aufrufen.

Login Daten:
============
Ihr User "tf_test" und das zugehörige Passwort.